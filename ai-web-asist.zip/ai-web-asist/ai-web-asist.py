import asyncio
import wx
import wx.aui
import json
import os
from datetime import datetime
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from browser_use import Agent, Browser, BrowserConfig
import threading

load_dotenv()

class TaskConfig:
    def __init__(self, name, description, task_text):
        self.name = name
        self.description = description
        self.task_text = task_text
        self.created_at = datetime.now().isoformat()
    
    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "task_text": self.task_text,
            "created_at": self.created_at
        }
    
    @staticmethod
    def from_dict(data):
        task = TaskConfig(data["name"], data["description"], data["task_text"])
        task.created_at = data["created_at"]
        return task

class TaskHistoryPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        self.history = []
        self.create_ui()
    
    def create_ui(self):
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # History controls panel
        controls_sizer = wx.BoxSizer(wx.HORIZONTAL)
        
        # Clear button
        self.clear_btn = wx.Button(self, label="Clear History")
        self.clear_btn.SetName("Clear History Button")
        self.clear_btn.Bind(wx.EVT_BUTTON, self.on_clear)
        controls_sizer.Add(self.clear_btn, 0, wx.ALL, 5)
        
        # Export button
        self.export_btn = wx.Button(self, label="Export History")
        self.export_btn.SetName("Export History Button")
        self.export_btn.Bind(wx.EVT_BUTTON, self.on_export)
        controls_sizer.Add(self.export_btn, 0, wx.ALL, 5)
        
        main_sizer.Add(controls_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        # History list with accessibility
        self.history_ctrl = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.HSCROLL)
        self.history_ctrl.SetFont(wx.Font(10, wx.FONTFAMILY_TELETYPE, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        self.history_ctrl.SetName("Task History Log")
        
        main_sizer.Add(self.history_ctrl, 1, wx.EXPAND | wx.ALL, 5)
        
        self.SetSizer(main_sizer)
    
    def on_clear(self, event):
        if wx.MessageBox("Are you sure you want to clear the history?",
                        "Confirm Clear History",
                        wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION) == wx.YES:
            self.history = []
            self.history_ctrl.SetValue("")
    
    def on_export(self, event):
        with wx.FileDialog(self, "Export Task History", 
                         wildcard="Text files (*.txt)|*.txt",
                         style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as fileDialog:
            
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            
            pathname = fileDialog.GetPath()
            try:
                with open(pathname, 'w', encoding='utf-8') as file:
                    file.write("\n".join(self.history))
                wx.MessageBox("History exported successfully!", "Success", wx.OK | wx.ICON_INFORMATION)
            except IOError:
                wx.MessageBox("Cannot save history file!", "Error", wx.OK | wx.ICON_ERROR)
    
    def add_log(self, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.history.append(log_entry)
        wx.CallAfter(self.history_ctrl.AppendText, f"{log_entry}\n")

class AgentPanel(wx.Panel):
    def __init__(self, parent, task_history):
        super().__init__(parent)
        self.task_history = task_history
        self.running = False
        self.create_ui()
    
    def create_ui(self):
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Task configuration section
        config_sizer = wx.StaticBoxSizer(wx.VERTICAL, self, "Task Configuration")
        
        # Task name with accessibility
        name_sizer = wx.BoxSizer(wx.HORIZONTAL)
        name_label = wx.StaticText(self, label="Task Name:")
        name_label.SetName("Task Name Label")
        self.name_input = wx.TextCtrl(self)
        self.name_input.SetName("Task Name Input")
        name_sizer.Add(name_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        name_sizer.Add(self.name_input, 1)
        config_sizer.Add(name_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        # Task description with accessibility
        desc_label = wx.StaticText(self, label="Description:")
        desc_label.SetName("Description Label")
        self.desc_input = wx.TextCtrl(self, style=wx.TE_MULTILINE)
        self.desc_input.SetName("Description Input")
        config_sizer.Add(desc_label, 0, wx.ALL, 5)
        config_sizer.Add(self.desc_input, 0, wx.EXPAND | wx.ALL, 5)
        
        # Task input with accessibility
        task_label = wx.StaticText(self, label="Task:")
        task_label.SetName("Task Label")
        self.task_input = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_RICH2)
        self.task_input.SetMinSize((400, 100))
        self.task_input.SetHint("Enter your task here...")
        self.task_input.SetName("Task Input Field")
        
        config_sizer.Add(task_label, 0, wx.ALL, 5)
        config_sizer.Add(self.task_input, 1, wx.EXPAND | wx.ALL, 5)
        
        main_sizer.Add(config_sizer, 1, wx.EXPAND | wx.ALL, 5)
        
        # Buttons with accessibility
        button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        
        self.save_btn = wx.Button(self, label="Save Configuration")
        self.save_btn.SetName("Save Configuration Button")
        self.save_btn.Bind(wx.EVT_BUTTON, self.on_save_config)
        button_sizer.Add(self.save_btn, 0, wx.ALL, 5)
        
        self.load_btn = wx.Button(self, label="Load Configuration")
        self.load_btn.SetName("Load Configuration Button")
        self.load_btn.Bind(wx.EVT_BUTTON, self.on_load_config)
        button_sizer.Add(self.load_btn, 0, wx.ALL, 5)
        
        self.share_btn = wx.Button(self, label="Share Task")
        self.share_btn.SetName("Share Task Button")
        self.share_btn.Bind(wx.EVT_BUTTON, self.on_share)
        button_sizer.Add(self.share_btn, 0, wx.ALL, 5)
        
        self.run_button = wx.Button(self, label="Run Task")
        self.run_button.SetName("Run Task Button")
        self.run_button.Bind(wx.EVT_BUTTON, self.on_run)
        button_sizer.Add(self.run_button, 0, wx.ALL, 5)
        
        self.stop_button = wx.Button(self, label="Stop")
        self.stop_button.SetName("Stop Task Button")
        self.stop_button.Disable()
        self.stop_button.Bind(wx.EVT_BUTTON, self.on_stop)
        button_sizer.Add(self.stop_button, 0, wx.ALL, 5)
        
        main_sizer.Add(button_sizer, 0, wx.ALIGN_RIGHT | wx.ALL, 5)
        
        self.SetSizer(main_sizer)
    
    def on_save_config(self, event):
        if not self.name_input.GetValue().strip():
            wx.MessageBox("Please enter a task name!", "Error", wx.OK | wx.ICON_ERROR)
            return
        
        task_config = TaskConfig(
            self.name_input.GetValue(),
            self.desc_input.GetValue(),
            self.task_input.GetValue()
        )
        
        with wx.FileDialog(self, "Save Task Configuration",
                         wildcard="JSON files (*.json)|*.json",
                         style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as fileDialog:
            
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            
            pathname = fileDialog.GetPath()
            try:
                with open(pathname, 'w', encoding='utf-8') as file:
                    json.dump(task_config.to_dict(), file, indent=4)
                wx.MessageBox("Configuration saved successfully!", "Success", wx.OK | wx.ICON_INFORMATION)
            except IOError:
                wx.MessageBox("Cannot save configuration file!", "Error", wx.OK | wx.ICON_ERROR)
    
    def on_load_config(self, event):
        with wx.FileDialog(self, "Load Task Configuration",
                         wildcard="JSON files (*.json)|*.json",
                         style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:
            
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            
            pathname = fileDialog.GetPath()
            try:
                with open(pathname, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    task_config = TaskConfig.from_dict(data)
                    
                    self.name_input.SetValue(task_config.name)
                    self.desc_input.SetValue(task_config.description)
                    self.task_input.SetValue(task_config.task_text)
                    
                    self.task_history.add_log(f"Loaded configuration: {task_config.name}")
            except IOError:
                wx.MessageBox("Cannot read configuration file!", "Error", wx.OK | wx.ICON_ERROR)
    
    def on_share(self, event):
        if not self.name_input.GetValue().strip():
            wx.MessageBox("Please save the configuration first!", "Error", wx.OK | wx.ICON_ERROR)
            return
        
        task_config = TaskConfig(
            self.name_input.GetValue(),
            self.desc_input.GetValue(),
            self.task_input.GetValue()
        )
        
        share_dialog = wx.Dialog(self, title="Share Task", size=(400, 300))
        dialog_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Create text area with task details
        share_text = wx.TextCtrl(share_dialog, style=wx.TE_MULTILINE | wx.TE_READONLY)
        share_text.SetValue(
            f"Task Name: {task_config.name}\n"
            f"Description: {task_config.description}\n"
            f"Task: {task_config.task_text}\n"
            f"Created: {task_config.created_at}"
        )
        
        dialog_sizer.Add(share_text, 1, wx.EXPAND | wx.ALL, 5)
        
        # Add copy button
        copy_btn = wx.Button(share_dialog, label="Copy to Clipboard")
        def on_copy(event):
            if wx.TheClipboard.Open():
                wx.TheClipboard.SetData(wx.TextDataObject(share_text.GetValue()))
                wx.TheClipboard.Close()
                wx.MessageBox("Copied to clipboard!", "Success", wx.OK | wx.ICON_INFORMATION)
        
        copy_btn.Bind(wx.EVT_BUTTON, on_copy)
        dialog_sizer.Add(copy_btn, 0, wx.ALIGN_CENTER | wx.ALL, 5)
        
        share_dialog.SetSizer(dialog_sizer)
        share_dialog.ShowModal()
        share_dialog.Destroy()
    
    def on_run(self, event):
        if not self.task_input.GetValue().strip():
            wx.MessageBox("Please enter a task first!", "Error", wx.OK | wx.ICON_ERROR)
            return
        
        self.running = True
        self.run_button.Disable()
        self.stop_button.Enable()
        self.task_input.Disable()
        self.save_btn.Disable()
        self.load_btn.Disable()
        self.share_btn.Disable()
        
        thread = threading.Thread(target=self.run_agent)
        thread.start()
    
    def on_stop(self, event):
        self.running = False
        self.run_button.Enable()
        self.stop_button.Disable()
        self.task_input.Enable()
        self.save_btn.Enable()
        self.load_btn.Enable()
        self.share_btn.Enable()
    
    def run_agent(self):
        async def run_task():
            try:
                llm = ChatOpenAI(model='gpt-4o', temperature=0.7)
                browser = Browser(config=BrowserConfig(headless=False))
                context = await browser.new_context()
                
                try:
                    agent = Agent(
                        task=self.task_input.GetValue(),
                        llm=llm,
                        browser_context=context
                    )
                    
                    self.task_history.add_log(f"Starting task: {self.task_input.GetValue()}")
                    await agent.run()
                    self.task_history.add_log("Task completed successfully!")
                    
                    while self.running:
                        await asyncio.sleep(1)
                        
                except Exception as e:
                    self.task_history.add_log(f"Error during task execution: {str(e)}")
                finally:
                    if not self.running:
                        await context.close()
                        await browser.close()
                        
            except Exception as e:
                self.task_history.add_log(f"Error initializing agent: {str(e)}")
            
            wx.CallAfter(self.on_stop, None)
        
        asyncio.run(run_task())

class MainFrame(wx.Frame):
    def __init__(self):
        super().__init__(parent=None, title="AI Web Assistant", size=(800, 600))
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create main panel
        main_panel = wx.Panel(self)
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Create toolbar
        self.create_toolbar()
        
        # Create the notebook for tabs
        self.notebook = wx.Notebook(main_panel)
        self.notebook.SetName("Main Tab Control")  # For accessibility
        
        # Create panels
        self.task_history = TaskHistoryPanel(self.notebook)
        self.agent_panel = AgentPanel(self.notebook, self.task_history)
        
        # Add pages to notebook with accessible names
        self.notebook.AddPage(self.agent_panel, "Agent")
        self.notebook.AddPage(self.task_history, "Task History")
        
        # Add notebook to main sizer
        main_sizer.Add(self.notebook, 1, wx.EXPAND | wx.ALL, 5)
        
        # Create status bar
        self.CreateStatusBar()
        self.SetStatusText("Ready")
        
        main_panel.SetSizer(main_sizer)
        
        # Set up keyboard shortcuts
        self.setup_accelerators()
        
        # Center the window
        self.Center()
    
    def create_toolbar(self):
        toolbar = self.CreateToolBar()
        toolbar.SetName("Main Toolbar")  # For accessibility
        
        # Add quick access tools
        run_tool = toolbar.AddTool(wx.ID_ANY, "Run Task", 
            wx.ArtProvider.GetBitmap(wx.ART_GO_FORWARD, wx.ART_TOOLBAR),
            "Run Current Task")
        stop_tool = toolbar.AddTool(wx.ID_ANY, "Stop Task",
            wx.ArtProvider.GetBitmap(wx.ART_CROSS_MARK, wx.ART_TOOLBAR),
            "Stop Current Task")
        
        toolbar.AddSeparator()
        
        save_tool = toolbar.AddTool(wx.ID_ANY, "Save",
            wx.ArtProvider.GetBitmap(wx.ART_FILE_SAVE, wx.ART_TOOLBAR),
            "Save Configuration")
        load_tool = toolbar.AddTool(wx.ID_ANY, "Load",
            wx.ArtProvider.GetBitmap(wx.ART_FILE_OPEN, wx.ART_TOOLBAR),
            "Load Configuration")
        
        toolbar.Realize()
        
        # Bind toolbar events
        self.Bind(wx.EVT_TOOL, lambda e: self.agent_panel.on_run(e), run_tool)
        self.Bind(wx.EVT_TOOL, lambda e: self.agent_panel.on_stop(e), stop_tool)
        self.Bind(wx.EVT_TOOL, lambda e: self.agent_panel.on_save_config(e), save_tool)
        self.Bind(wx.EVT_TOOL, lambda e: self.agent_panel.on_load_config(e), load_tool)
    
    def create_menu_bar(self):
        menu_bar = wx.MenuBar()
        
        # File Menu
        file_menu = wx.Menu()
        save_config = file_menu.Append(wx.ID_SAVE, "Save Configuration\tCtrl+S")
        load_config = file_menu.Append(wx.ID_OPEN, "Load Configuration\tCtrl+O")
        file_menu.AppendSeparator()
        export_history = file_menu.Append(wx.ID_ANY, "Export History\tCtrl+E")
        file_menu.AppendSeparator()
        exit_item = file_menu.Append(wx.ID_EXIT, "Exit\tAlt+F4")
        
        # Task Menu
        task_menu = wx.Menu()
        run_task = task_menu.Append(wx.ID_ANY, "Run Task\tCtrl+R")
        stop_task = task_menu.Append(wx.ID_ANY, "Stop Task\tCtrl+T")
        task_menu.AppendSeparator()
        share_task = task_menu.Append(wx.ID_ANY, "Share Task\tCtrl+H")
        
        # View Menu
        view_menu = wx.Menu()
        view_agent = view_menu.Append(wx.ID_ANY, "Show Agent Tab\tAlt+1")
        view_history = view_menu.Append(wx.ID_ANY, "Show History Tab\tAlt+2")
        
        # Help Menu
        help_menu = wx.Menu()
        about_item = help_menu.Append(wx.ID_ABOUT, "About")
        
        # Add menus to menu bar
        menu_bar.Append(file_menu, "File")
        menu_bar.Append(task_menu, "Task")
        menu_bar.Append(view_menu, "View")
        menu_bar.Append(help_menu, "Help")
        
        self.SetMenuBar(menu_bar)
        
        # Bind menu events
        self.Bind(wx.EVT_MENU, lambda e: self.agent_panel.on_save_config(e), save_config)
        self.Bind(wx.EVT_MENU, lambda e: self.agent_panel.on_load_config(e), load_config)
        self.Bind(wx.EVT_MENU, lambda e: self.task_history.on_export(e), export_history)
        self.Bind(wx.EVT_MENU, lambda e: self.agent_panel.on_run(e), run_task)
        self.Bind(wx.EVT_MENU, lambda e: self.agent_panel.on_stop(e), stop_task)
        self.Bind(wx.EVT_MENU, lambda e: self.agent_panel.on_share(e), share_task)
        self.Bind(wx.EVT_MENU, lambda e: self.notebook.SetSelection(0), view_agent)
        self.Bind(wx.EVT_MENU, lambda e: self.notebook.SetSelection(1), view_history)
        self.Bind(wx.EVT_MENU, self.on_exit, exit_item)
        self.Bind(wx.EVT_MENU, self.on_about, about_item)
    
    def setup_accelerators(self):
        # Create accelerator table
        accel_entries = [
            (wx.ACCEL_CTRL, ord('R'), self.agent_panel.run_button.GetId()),
            (wx.ACCEL_CTRL, ord('T'), self.agent_panel.stop_button.GetId()),
            (wx.ACCEL_CTRL, ord('E'), self.task_history.export_btn.GetId()),
            (wx.ACCEL_CTRL, ord('S'), wx.ID_SAVE),
            (wx.ACCEL_CTRL, ord('O'), wx.ID_OPEN),
            (wx.ACCEL_ALT, ord('1'), wx.ID_ANY),
            (wx.ACCEL_ALT, ord('2'), wx.ID_ANY),
        ]
        accel_table = wx.AcceleratorTable(accel_entries)
        self.SetAcceleratorTable(accel_table)
    
    def on_exit(self, event):
        self.Close()
    
    def on_about(self, event):
        wx.MessageBox("AI Web Assistant\nVersion 1.0\n\nAn intelligent web automation tool",
                     "About AI Web Assistant",
                     wx.OK | wx.ICON_INFORMATION)

if __name__ == '__main__':
    app = wx.App()
    frame = MainFrame()
    frame.Show()
    app.MainLoop()
