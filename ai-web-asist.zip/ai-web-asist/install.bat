@echo off
echo Sanal ortam olusturuluyor...
python -m venv venv

echo Sanal ortam etkinlestiriliyor...
call venv\Scripts\activate

echo Pip paket yöneticisi güncelleniyor...
python -m pip install --upgrade pip

echo Gerekli paketler yukleniyor...
pip install -r requirements.txt

echo Kurulum tamamlandi.
pause
