@echo off
REM Sanal ortamın etkin olup olmadığını kontrol et
if not defined VIRTUAL_ENV (
    echo Sanal ortam etkin değil, etkinleştiriliyor...
    call venv\Scripts\activate
    echo Sanal ortam etkinleştirildi.
    python ai-web-asist.py
) else (
    echo Sanal ortam zaten etkin. Uygulama başlatılıyor...
    python ai-web-asist.py
)
