# Tarayıcı Otomasyon Asistanı

Doğal dil talimatları kullanarak web görevlerini otomatikleştiren, Gemini AI ile çalışan modern bir web uygulaması.

## Özellikler

- 🌐 **Web Otomasyon**: Doğal dil kullanarak web görevlerini otomatize edin
- 🤖 **LangChain ve Gemini AI Entegrasyonu**: İleri NLP teknolojileri ile güçlendirilmiş
- 📸 **Ekran Görüntüsü Yakalama**: Otomasyonun her adımında görsel geri bildirim
- 📊 **Eylem Geçmişi**: Tarayıcıda gerçekleştirilen tüm eylemlerin kaydı
- 💾 **Yapılandırma Yönetimi**: Görevleri kaydedip daha sonra kullanın
- 🔄 **Paylaşılabilir Görevler**: Görevleri başkalarıyla kolayca paylaşın
- ⚙️ **Gelişmiş Seçenekler**: Otomasyon davranışını özelleştirin
- 🌙 **Karanlık/Aydınlık Mod**: Otomatik tema desteği
- ♿ **Erişilebilirlik Özellikleri**: WCAG standartlarına uygun tasarım

## Kurulum

1. Bu depoyu klonlayın:
   ```
   git clone https://github.com/kullaniciadi/tarayici-otomasyon-asistani.git
   cd tarayici-otomasyon-asistani
   ```

2. Gerekli bağımlılıkları yükleyin:
   ```
   pip install -r requirements.txt
   ```

3. Playwright tarayıcılarını yükleyin:
   ```
   python -m playwright install
   ```

4. Proje kök dizininde `.env` dosyası oluşturun ve Gemini API anahtarınızı ekleyin:
   ```
   GEMINI_API_KEY=gemini_api_anahtariniz_buraya
   ```

## Kullanım

1. Uygulamayı başlatın:
   ```
   python app.py
   ```

2. Tarayıcınızı açın ve `http://localhost:5000` adresine gidin

3. Yeni bir görev oluşturun:
   - Görev adını girin
   - (İsteğe bağlı) Bir açıklama ekleyin
   - Tarayıcı ajanı için doğal dilde detaylı talimatlar yazın
   - "Görevi Çalıştır" düğmesine tıklayın

4. Kontrol düğmelerini kullanarak:
   - Görevi Çalıştır: Mevcut görevi çalıştırın
   - Görevi Durdur: Çalışan görevi durdurun
   - Yapılandırmayı Kaydet: Mevcut görevi bir dosyaya kaydedin
   - Görevi Paylaş: Görevin paylaşılabilir bir metin temsili oluşturun

5. Son görevler tarayıcınızın yerel depolamasında hızlı erişim için saklanır

## Görev Örnekleri

İşte deneyebileceğiniz bazı görev örnekleri:

1. **Bilgi Arama:**
   ```
   Google'a git, "yapay zeka son gelişmeler" için ara ve ilk 5 arama sonucunun başlıklarını topla.
   ```

2. **Form Doldurma:**
   ```
   example.com/contact adresine git, iletişim formunu "Ahmet Yılmaz" adı, "ahmet@ornek.com" e-postası ve "Merhaba, hizmetlerinizle ilgileniyorum" mesajıyla doldur, ardından formu gönder.
   ```

3. **Veri Çıkarma:**
   ```
   weather.com adresine git, İstanbul için önümüzdeki 3 gün için hava durumu tahminini kontrol et ve sıcaklık en yüksek ve en düşük değerlerini çıkar.
   ```

## Yapılandırma Dosyaları

Görev yapılandırmaları aşağıdaki yapıya sahip JSON dosyaları olarak kaydedilir:
```json
{
  "name": "Görev Adı",
  "description": "Görev Açıklaması",
  "task_text": "Detaylı görev talimatları...",
  "created_at": "2023-09-28T14:30:00.000Z",
  "advanced_options": {
    "maxSteps": 25,
    "headless": false
  }
}
```

"Yapılandırma Yükle" düğmesini kullanarak bu yapılandırmaları yükleyebilirsiniz.

## Erişilebilirlik Özellikleri

- Yüksek kontrast modu
- Büyük yazı modu
- Tam klavye gezinme desteği
- Ekran okuyucu dostu

## Katkıda Bulunma

Katkılarınızı bekliyoruz! Lütfen bir Pull Request göndermekten çekinmeyin. 