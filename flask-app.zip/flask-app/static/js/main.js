// DOM Elemanları - Ana Kontroller
const taskNameInput = document.getElementById('taskName');
const taskDescriptionInput = document.getElementById('taskDescription');
const taskTextInput = document.getElementById('taskText');
const runTaskBtn = document.getElementById('runTaskBtn');
const stopTaskBtn = document.getElementById('stopTaskBtn');
const saveConfigBtn = document.getElementById('saveConfigBtn');
const shareTaskBtn = document.getElementById('shareTaskBtn');
const loadConfigBtn = document.getElementById('loadConfigBtn');
const newTaskBtn = document.getElementById('newTaskBtn');
const logDisplay = document.getElementById('logDisplay');
const clearLogBtn = document.getElementById('clearLogBtn');
const copyLogBtn = document.getElementById('copyLogBtn');
const recentTasksList = document.getElementById('recentTasksList');
const statusText = document.getElementById('statusText');
const taskForm = document.getElementById('taskForm');
const taskProgressBar = document.getElementById('taskProgressBar');
const progressDetails = document.getElementById('progressDetails');
const screenshotsContainer = document.getElementById('screenshotsContainer') || document.createElement('div'); // Ekran görüntüleri konteyneri

// Gelişmiş seçenekler
const maxStepsInput = document.getElementById('maxSteps');
const browserHeadlessSelect = document.getElementById('browserHeadless');

// Erişilebilirlik kontrolleri
const highContrastMode = document.getElementById('highContrastMode');
const largeTextMode = document.getElementById('largeTextMode');

// Bootstrap modal elemanları
const loadConfigModal = new bootstrap.Modal(document.getElementById('loadConfigModal'));
const shareTaskModal = new bootstrap.Modal(document.getElementById('shareTaskModal'));
const configFilenameInput = document.getElementById('configFilename');
const confirmLoadConfigBtn = document.getElementById('confirmLoadConfig');
const shareTextArea = document.getElementById('shareText');
const copyShareTextBtn = document.getElementById('copyShareText');
const toastContainer = document.getElementById('toastContainer');

// Yerel depolama anahtarları
const RECENT_TASKS_KEY = 'recentTasks';
const ACCESSIBILITY_SETTINGS_KEY = 'accessibilitySettings';
const ADVANCED_OPTIONS_KEY = 'advancedOptions';
const MAX_RECENT_TASKS = 5;

// Durum değişkenleri
let isTaskRunning = false;
let recentTasks = JSON.parse(localStorage.getItem(RECENT_TASKS_KEY) || '[]');
let accessibilitySettings = JSON.parse(localStorage.getItem(ACCESSIBILITY_SETTINGS_KEY) || '{"highContrast": false, "largeText": false}');
let advancedOptions = JSON.parse(localStorage.getItem(ADVANCED_OPTIONS_KEY) || '{"maxSteps": 25, "headless": false}');
let logPollingInterval = null;
let progressUpdateInterval = null;
let screenshotsPollingInterval = null;
let currentProgressValue = 0;
let screenshots = [];
let actionHistory = [];

// Uygulamayı başlat
function init() {
    // Kaydedilmiş erişilebilirlik ayarlarını uygula
    if (accessibilitySettings.highContrast) {
        document.body.classList.add('high-contrast');
        highContrastMode.checked = true;
    }
    
    if (accessibilitySettings.largeText) {
        document.body.classList.add('large-text');
        largeTextMode.checked = true;
    }
    
    // Kaydedilmiş tercihlerden gelişmiş seçenekleri ayarla
    maxStepsInput.value = advancedOptions.maxSteps;
    browserHeadlessSelect.value = advancedOptions.headless.toString();
    
    updateRecentTasksList();
    setupEventListeners();
    startLogPolling();
    startScreenshotsPolling();
    updateStatusIndicator('Hazır');
    
    // API bağlantısını kontrol et
    testConnection();
}

// API bağlantısını test et
function testConnection() {
    fetch('/test_connection')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                showNotification('API bağlantısı başarılı: ' + data.message, 'success');
                updateToolsStatus(data.available_tools);
            } else {
                showNotification('API bağlantı hatası: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Bağlantı hatası:', error);
            showNotification('Bağlantı hatası: ' + error.message, 'error');
        });
}

// Araçların durumunu güncelle
function updateToolsStatus(tools) {
    const toolsList = document.getElementById('toolsList');
    if (toolsList) {
        toolsList.innerHTML = tools.map(tool => 
            `<li class="list-group-item">
                <i class="fas fa-check-circle text-success"></i> ${tool}
            </li>`
        ).join('');
    }
}

// UI etkileşimleri için olay dinleyicileri kur
function setupEventListeners() {
    // Form doğrulama
    taskForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (taskForm.checkValidity()) {
            runTask();
        } else {
            taskForm.classList.add('was-validated');
        }
    });
    
    // Görev yürütme kontrolleri
    runTaskBtn.addEventListener('click', () => {
        if (taskForm.checkValidity()) {
            runTask();
        } else {
            taskForm.classList.add('was-validated');
        }
    });
    
    stopTaskBtn.addEventListener('click', stopTask);
    
    // Yapılandırma yönetimi
    saveConfigBtn.addEventListener('click', saveConfig);
    loadConfigBtn.addEventListener('click', () => loadConfigModal.show());
    confirmLoadConfigBtn.addEventListener('click', loadConfig);
    
    // Görev yönetimi
    newTaskBtn.addEventListener('click', clearTaskForm);
    shareTaskBtn.addEventListener('click', shareTask);
    copyShareTextBtn.addEventListener('click', copyToClipboard);
    clearLogBtn.addEventListener('click', clearLog);
    copyLogBtn.addEventListener('click', copyLogToClipboard);
    
    // Gelişmiş seçenekler
    maxStepsInput.addEventListener('change', saveAdvancedOptions);
    browserHeadlessSelect.addEventListener('change', saveAdvancedOptions);
    
    // Erişilebilirlik ayarları
    highContrastMode.addEventListener('change', toggleHighContrast);
    largeTextMode.addEventListener('change', toggleLargeText);
    
    // Son görevler listesindeki tıklamaları dinle
    recentTasksList.addEventListener('click', (e) => {
        const taskItem = e.target.closest('.recent-task');
        if (taskItem) {
            loadTaskFromHistory(taskItem.dataset.index);
        }
    });
    
    // Veri temizleme
    document.getElementById('clearAllBtn')?.addEventListener('click', () => {
        if (confirm('Tüm veri geçmişini silmek istediğinizden emin misiniz?')) {
            clearAllData();
        }
    });
    
    // Klavye navigasyonu desteği ekle
    document.addEventListener('keydown', (e) => {
        // Ctrl+Enter görevi çalıştır
        if (e.ctrlKey && e.key === 'Enter') {
            if (!isTaskRunning && taskForm.checkValidity()) {
                runTask();
                e.preventDefault();
            }
        }
        // Escape görevi durdur
        else if (e.key === 'Escape' && isTaskRunning) {
            stopTask();
            e.preventDefault();
        }
    });
}

// Tüm verileri temizle
function clearAllData() {
    fetch('/clear_all', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        showNotification(data.message, 'success');
        clearLog();
        updateScreenshots([]);
    })
    .catch(error => {
        showNotification('Hata: ' + error.message, 'error');
    });
}

// Erişilebilirlik geçişleri
function toggleHighContrast() {
    document.body.classList.toggle('high-contrast');
    accessibilitySettings.highContrast = highContrastMode.checked;
    localStorage.setItem(ACCESSIBILITY_SETTINGS_KEY, JSON.stringify(accessibilitySettings));
    
    // Ekran okuyuculara değişikliği duyur
    announceToScreenReader(`Yüksek kontrast modu ${highContrastMode.checked ? 'etkinleştirildi' : 'devre dışı bırakıldı'}`);
}

function toggleLargeText() {
    document.body.classList.toggle('large-text');
    accessibilitySettings.largeText = largeTextMode.checked;
    localStorage.setItem(ACCESSIBILITY_SETTINGS_KEY, JSON.stringify(accessibilitySettings));
    
    // Ekran okuyuculara değişikliği duyur
    announceToScreenReader(`Büyük yazı modu ${largeTextMode.checked ? 'etkinleştirildi' : 'devre dışı bırakıldı'}`);
}

// Ekran okuyuculara değişiklikleri duyurmak için yardımcı fonksiyon
function announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'assertive');
    announcement.setAttribute('class', 'sr-only');
    announcement.textContent = message;
    document.body.appendChild(announcement);
    
    // Duyuru işlendikten sonra kaldır
    setTimeout(() => {
        document.body.removeChild(announcement);
    }, 1000);
}

// Gelişmiş seçenekleri kaydet
function saveAdvancedOptions() {
    advancedOptions = {
        maxSteps: parseInt(maxStepsInput.value) || 25,
        headless: browserHeadlessSelect.value === 'true'
    };
    
    localStorage.setItem(ADVANCED_OPTIONS_KEY, JSON.stringify(advancedOptions));
    showNotification('Gelişmiş seçenekler kaydedildi', 'info');
}

// Tarayıcı görevini çalıştır
function runTask() {
    const taskText = taskTextInput.value.trim();
    if (!taskText) {
        showNotification('Lütfen görev talimatlarını girin', 'warning');
        return;
    }
    
    // İlerleme göstergelerini sıfırla
    resetProgress();
    
    // Ekran görüntülerini temizle
    updateScreenshots([]);
    
    // Çalıştır düğmesini devre dışı bırak ve durdur düğmesini etkinleştir
    setTaskRunningState(true);
    updateStatusIndicator('Görev çalışıyor...');
    
    // Bir adı varsa son görevlere ekle
    const taskName = taskNameInput.value.trim();
    if (taskName) {
        addToRecentTasks({
            name: taskName,
            description: taskDescriptionInput.value.trim(),
            task_text: taskText,
            created_at: new Date().toISOString()
        });
    }
    
    // İlerleme simülasyonunu başlat
    startProgressSimulation();
    
    // Görevi sunucuya gönder
    fetch('/run_task', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            'task_text': taskText
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        appendToLog(data.message);
    })
    .catch(error => {
        appendToLog(`Hata: ${error.message}`);
        updateStatusIndicator('Hata');
        setTaskRunningState(false);
        stopProgressSimulation();
        showNotification('Görev çalıştırılırken hata: ' + error.message, 'error');
    });
}

// Çalışan görevi durdur
function stopTask() {
    fetch('/stop_task', {
        method: 'POST',
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        appendToLog(data.message);
        updateStatusIndicator('Durduruldu');
        setTaskRunningState(false);
        stopProgressSimulation();
        showNotification('Görev durduruldu', 'info');
    })
    .catch(error => {
        appendToLog(`Görevi durdururken hata: ${error.message}`);
        showNotification('Görevi durdururken hata: ' + error.message, 'error');
    });
}

// Mevcut yapılandırmayı kaydet
function saveConfig() {
    const taskName = taskNameInput.value.trim();
    const taskDescription = taskDescriptionInput.value.trim();
    const taskText = taskTextInput.value.trim();
    
    if (!taskName || !taskText) {
        showNotification('Lütfen bir görev adı ve talimatlar belirtin', 'warning');
        return;
    }
    
    const config = {
        name: taskName,
        description: taskDescription,
        task_text: taskText,
        created_at: new Date().toISOString(),
        advanced_options: advancedOptions
    };
    
    fetch('/save_config', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(config)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        showNotification(data.message, 'success');
    })
    .catch(error => {
        showNotification(`Hata: ${error.message}`, 'error');
    });
}

// Bir yapılandırmayı dosyadan yükle
function loadConfig() {
    const filename = configFilenameInput.value.trim();
    if (!filename) {
        showNotification('Lütfen bir dosya adı girin', 'warning');
        return;
    }
    
    const formData = new FormData();
    formData.append('filename', filename);
    
    fetch('/load_config', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.config) {
            loadTaskFromData(data.config);
            showNotification(data.message, 'success');
        } else {
            showNotification(data.message, 'warning');
        }
        loadConfigModal.hide();
    })
    .catch(error => {
        showNotification(`Hata: ${error.message}`, 'error');
    });
}

// Görev verilerini forma yükle
function loadTaskFromData(taskData) {
    taskNameInput.value = taskData.name || '';
    taskDescriptionInput.value = taskData.description || '';
    taskTextInput.value = taskData.task_text || '';
    
    // Gelişmiş ayarları yükle (varsa)
    if (taskData.advanced_options) {
        advancedOptions = taskData.advanced_options;
        maxStepsInput.value = advancedOptions.maxSteps || 25;
        browserHeadlessSelect.value = (advancedOptions.headless || false).toString();
        saveAdvancedOptions();
    }
    
    // Doğrulama durumunu sıfırla
    taskForm.classList.remove('was-validated');
}

// Mevcut görevi paylaş
function shareTask() {
    const taskName = taskNameInput.value.trim();
    const taskDescription = taskDescriptionInput.value.trim();
    const taskText = taskTextInput.value.trim();
    
    if (!taskName || !taskText) {
        showNotification('Lütfen bir görev adı ve talimatlar belirtin', 'warning');
        return;
    }
    
    const taskData = {
        name: taskName,
        description: taskDescription,
        task_text: taskText,
        created_at: new Date().toISOString(),
        advanced_options: advancedOptions
    };
    
    fetch('/share_task', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(taskData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        shareTextArea.value = data.share_text;
        shareTaskModal.show();
    })
    .catch(error => {
        showNotification(`Hata: ${error.message}`, 'error');
    });
}

// Paylaşım metnini panoya kopyala
function copyToClipboard() {
    shareTextArea.select();
    document.execCommand('copy');
    showNotification('Panoya kopyalandı!', 'success');
}

// Logu panoya kopyala
function copyLogToClipboard() {
    const range = document.createRange();
    range.selectNode(logDisplay);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);
    document.execCommand('copy');
    window.getSelection().removeAllRanges();
    showNotification('Log panoya kopyalandı!', 'success');
}

// Log ekranını temizle
function clearLog() {
    logDisplay.textContent = '';
    showNotification('Log temizlendi', 'info');
}

// Log ekranına ekle
function appendToLog(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}\n`;
    
    // Yeni giriş için bir metin düğümü oluştur
    const textNode = document.createTextNode(logEntry);
    
    // Metin düğümünü log ekranına ekle
    logDisplay.appendChild(textNode);
    
    // Aşağıya kaydır
    logDisplay.scrollTop = logDisplay.scrollHeight;
}

// Ekran görüntülerini güncelle
function updateScreenshots(screenshotUrls) {
    if (!screenshotsContainer) return;
    
    // Konteyneri temizle
    screenshotsContainer.innerHTML = '';
    
    if (screenshotUrls.length === 0) {
        const emptyMessage = document.createElement('p');
        emptyMessage.className = 'text-muted';
        emptyMessage.textContent = 'Henüz ekran görüntüsü yok';
        screenshotsContainer.appendChild(emptyMessage);
        return;
    }
    
    // Ekran görüntülerini ekle
    screenshotUrls.forEach(url => {
        const card = document.createElement('div');
        card.className = 'card mb-3 screenshot-card';
        
        const img = document.createElement('img');
        img.src = url;
        img.className = 'card-img-top screenshot-img';
        img.alt = 'Ekran görüntüsü';
        img.loading = 'lazy';
        
        const cardBody = document.createElement('div');
        cardBody.className = 'card-body';
        
        const timestamp = document.createElement('p');
        timestamp.className = 'card-text small text-muted';
        timestamp.textContent = new Date().toLocaleString();
        
        const downloadLink = document.createElement('a');
        downloadLink.href = url;
        downloadLink.className = 'btn btn-sm btn-primary';
        downloadLink.textContent = 'İndir';
        downloadLink.download = url.split('/').pop();
        
        cardBody.appendChild(timestamp);
        cardBody.appendChild(downloadLink);
        
        card.appendChild(img);
        card.appendChild(cardBody);
        
        screenshotsContainer.appendChild(card);
    });
}

// Ekran görüntülerini periyodik olarak sorgula
function startScreenshotsPolling() {
    if (screenshotsPollingInterval) {
        clearInterval(screenshotsPollingInterval);
    }
    
    screenshotsPollingInterval = setInterval(() => {
        if (isTaskRunning) {
            fetch('/get_screenshots')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.screenshots && data.screenshots.length > 0) {
                        updateScreenshots(data.screenshots);
                    }
                })
                .catch(error => {
                    console.error('Ekran görüntüsü sorgulama hatası:', error);
                });
        }
    }, 5000); // Her 5 saniyede bir sorgula
}

// Durum göstergesini güncelle
function updateStatusIndicator(status) {
    const statusMap = {
        'Hazır': 'Ready',
        'Görev çalışıyor...': 'Running task...',
        'Durduruldu': 'Stopped',
        'Hata': 'Error',
        'Tamamlandı': 'Completed'
    };
    
    statusText.textContent = status;
    
    // Duruma göre renk değiştir
    const statusClasses = {
        'Hazır': 'text-success',
        'Görev çalışıyor...': 'text-primary',
        'Durduruldu': 'text-warning',
        'Hata': 'text-danger',
        'Tamamlandı': 'text-success'
    };
    
    // Tüm mevcut durum sınıflarını kaldır
    Object.values(statusClasses).forEach(cls => {
        statusText.classList.remove(cls);
    });
    
    // Uygun sınıfı ekle
    if (statusClasses[status]) {
        statusText.classList.add(statusClasses[status]);
    }
}

// Bir görev çalışıyor mu durumuna göre UI durumunu ayarla
function setTaskRunningState(isRunning) {
    isTaskRunning = isRunning;
    runTaskBtn.disabled = isRunning;
    stopTaskBtn.disabled = !isRunning;
    saveConfigBtn.disabled = isRunning;
    
    // Görev çalışırken gelişmiş seçenekleri devre dışı bırak
    maxStepsInput.disabled = isRunning;
    browserHeadlessSelect.disabled = isRunning;
    
    if (isRunning) {
        runTaskBtn.classList.add('disabled');
        stopTaskBtn.classList.remove('disabled');
    } else {
        runTaskBtn.classList.remove('disabled');
        stopTaskBtn.classList.add('disabled');
    }
}

// İlerleme çubuğu fonksiyonları
function resetProgress() {
    currentProgressValue = 0;
    taskProgressBar.setAttribute('aria-valuenow', '0');
    taskProgressBar.querySelector('.progress-bar').style.width = '0%';
    progressDetails.textContent = 'Görev hazırlanıyor...';
}

function startProgressSimulation() {
    if (progressUpdateInterval) {
        clearInterval(progressUpdateInterval);
    }
    
    progressUpdateInterval = setInterval(() => {
        // %95'e yaklaştıkça yavaşlayan bir eğri ile ilerlemeyi simüle et
        if (currentProgressValue < 95) {
            const increment = Math.max(0.5, 5 * (1 - currentProgressValue / 100));
            currentProgressValue = Math.min(95, currentProgressValue + increment);
            updateProgress(currentProgressValue);
        }
    }, 1000);
}

function stopProgressSimulation() {
    if (progressUpdateInterval) {
        clearInterval(progressUpdateInterval);
        progressUpdateInterval = null;
    }
    
    // Görev tamamlandı veya durduruldu, %100'e ayarla
    currentProgressValue = 100;
    updateProgress(100);
}

function updateProgress(value) {
    taskProgressBar.setAttribute('aria-valuenow', value.toString());
    taskProgressBar.querySelector('.progress-bar').style.width = `${value}%`;
    
    // İlerleme detaylarını güncelle
    if (value < 25) {
        progressDetails.textContent = 'Tarayıcı başlatılıyor...';
    } else if (value < 50) {
        progressDetails.textContent = 'Tarayıcı başlatıldı, talimatlar işleniyor...';
    } else if (value < 75) {
        progressDetails.textContent = 'Tarayıcı eylemleri yürütülüyor...';
    } else if (value < 95) {
        progressDetails.textContent = 'Görev tamamlanıyor...';
    } else {
        progressDetails.textContent = 'Görev tamamlandı';
    }
}

// Son görevlere bir görev ekle
function addToRecentTasks(task) {
    // Zaten varsa kaldır
    recentTasks = recentTasks.filter(t => t.name !== task.name);
    
    // Başa ekle
    recentTasks.unshift(task);
    
    // MAX_RECENT_TASKS ile sınırla
    if (recentTasks.length > MAX_RECENT_TASKS) {
        recentTasks = recentTasks.slice(0, MAX_RECENT_TASKS);
    }
    
    // Yerel depolamaya kaydet
    localStorage.setItem(RECENT_TASKS_KEY, JSON.stringify(recentTasks));
    
    // UI'yı güncelle
    updateRecentTasksList();
}

// UI'daki son görevler listesini güncelle
function updateRecentTasksList() {
    recentTasksList.innerHTML = '';
    
    if (recentTasks.length === 0) {
        const emptyItem = document.createElement('li');
        emptyItem.className = 'list-group-item';
        emptyItem.textContent = 'Henüz görev yok';
        emptyItem.setAttribute('role', 'listitem');
        emptyItem.setAttribute('aria-label', 'Henüz görev yok');
        recentTasksList.appendChild(emptyItem);
        return;
    }
    
    recentTasks.forEach((task, index) => {
        const taskItem = document.createElement('li');
        taskItem.className = 'list-group-item recent-task';
        taskItem.dataset.index = index;
        taskItem.setAttribute('role', 'listitem');
        taskItem.setAttribute('aria-label', `Son görev: ${task.name}`);
        taskItem.setAttribute('tabindex', '0'); // Odaklanabilir yap
        
        // Etkinleştirme için klavye desteği ekle
        taskItem.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                loadTaskFromHistory(index);
                e.preventDefault();
            }
        });
        
        const taskName = document.createElement('div');
        taskName.className = 'fw-bold';
        taskName.textContent = task.name;
        
        const taskDesc = document.createElement('div');
        taskDesc.className = 'small text-muted';
        taskDesc.textContent = task.description || 'Açıklama yok';
        
        const taskDate = document.createElement('div');
        taskDate.className = 'small text-muted mt-1';
        const date = new Date(task.created_at);
        taskDate.textContent = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        
        taskItem.appendChild(taskName);
        taskItem.appendChild(taskDesc);
        taskItem.appendChild(taskDate);
        recentTasksList.appendChild(taskItem);
    });
}

// Geçmişten bir görev yükle
function loadTaskFromHistory(index) {
    const task = recentTasks[index];
    if (task) {
        loadTaskFromData(task);
        showNotification(`"${task.name}" görevi yüklendi`, 'info');
    }
}

// Görev formunu temizle
function clearTaskForm() {
    taskNameInput.value = '';
    taskDescriptionInput.value = '';
    taskTextInput.value = '';
    taskForm.classList.remove('was-validated');
    showNotification('Form temizlendi', 'info');
    resetProgress();
}

// Log güncellemeleri için sorgulama yap
function startLogPolling() {
    if (logPollingInterval) {
        clearInterval(logPollingInterval);
    }
    
    logPollingInterval = setInterval(() => {
        if (isTaskRunning) {
            fetch('/get_logs')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Ağ yanıtı uygun değil: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.logs && data.logs.length > 0) {
                        logDisplay.textContent = data.logs.join('\n');
                        logDisplay.scrollTop = logDisplay.scrollHeight;
                        
                        // Tamamlanma mesajlarını kontrol et
                        const lastLog = data.logs[data.logs.length - 1] || '';
                        if (lastLog.includes("tamamladı") || lastLog.includes("completed")) {
                            updateStatusIndicator('Tamamlandı');
                            setTaskRunningState(false);
                            stopProgressSimulation();
                            showNotification('Görev başarıyla tamamlandı', 'success');
                        } 
                        else if (lastLog.includes("Hata") || lastLog.includes("Error") || lastLog.includes("hata")) {
                            updateStatusIndicator('Hata');
                            setTaskRunningState(false);
                            stopProgressSimulation();
                            showNotification('Görev bir hatayla karşılaştı', 'error');
                        }
                    }
                })
                .catch(error => {
                    console.error('Log sorgulama hatası:', error);
                    // Her sorguda hata gösterme
                });
        }
    }, 2000); // Her 2 saniyede bir sorgula
}

// DOM yüklendiğinde uygulamayı başlat
document.addEventListener('DOMContentLoaded', init); 