import os
import asyncio
import threading
import json
from datetime import datetime
from flask import Flask, request, render_template, jsonify
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import SecretStr

# browser_use kütüphanesi (Agent, Browser, vb.)
from browser_use import Agent, Browser, BrowserConfig
from browser_use.browser.context import BrowserContextConfig

# .env dosyasından API anahtarını yükle
load_dotenv()
api_key = os.getenv('GEMINI_API_KEY')
if not api_key:
    raise ValueError("GEMINI_API_KEY is not set")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(24)

# Global değişkenler
global_browser = None
global_context = None
global_agent_thread = None
global_running = False
global_task_log = []  # Uygulama tarafı log kayıtları

def add_log(message: str):
    """Log kayıtlarını ekleyen yardımcı fonksiyon."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    global_task_log.append(log_entry)
    print(log_entry)

def create_llm():
    """LangChain Google GenerativeAI LLM oluşturan fonksiyon."""
    return ChatGoogleGenerativeAI(
        model="gemini-2.0-flash-exp",
        api_key=SecretStr(api_key),
        temperature=0.7,
        max_tokens=512,
        top_p=0.9
    )

def run_agent_background(task_text: str):
    """Agent görevini arka planda çalıştırmak için threading.Thread ile çağrılır."""
    async def run_agent():
        global global_browser, global_context, global_running
        try:
            llm = create_llm()

            # Tarayıcı başlatma (varsayılan Chromium)
            global_browser = Browser(
                config=BrowserConfig(
                    headless=False,
                    new_context_config=BrowserContextConfig(viewport_expansion=0)
                )
            )

            global_context = await global_browser.new_context()

            agent = Agent(
                task=task_text,
                llm=llm,
                browser_context=global_context,
                max_actions_per_step=5
            )
            add_log(f"Agent başlatıldı: {task_text}")

            # Agent’i 25 adım çalıştır
            await agent.run(max_steps=25)
            add_log("Agent görevi tamamladı. Tarayıcı açık kalıyor...")

            # Kullanıcı durdur diyene kadar bekle
            while global_running:
                await asyncio.sleep(1)

        except Exception as e:
            add_log(f"Agent çalışırken hata: {str(e)}")

    asyncio.run(run_agent())

@app.route("/")
def index():
    """
    Anasayfa: Mevcut log geçmişini index.html'e aktar.
    Front-end tarafında log satırları ters çevrilerek en son işlemin üstte görünmesi sağlanır.
    """
    return render_template("index.html", task_log="\n".join(global_task_log))

# -------------------------
# GÖREV KAYDET / YÜKLE
# -------------------------
@app.route("/save_task", methods=["POST"])
def save_task():
    """
    Görevi JSON olarak kaydetmek için:
      - payload: {
          "filename": "gorev.json",
          "data": {
              "name": "...",
              "description": "...",
              "task_text": "..."
          }
        }
    """
    try:
        payload = request.get_json()
        if not payload:
            return jsonify({"message": "Görev verisi alınamadı."}), 400

        filename = payload.get("filename", "task.json")
        data = payload.get("data", {})

        # JSON formatında kaydet
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        add_log(f"Görev kaydedildi: {filename}")
        return jsonify({"message": f"Görev {filename} dosyasına kaydedildi."})
    except Exception as e:
        add_log(f"Görev kaydedilirken hata: {str(e)}")
        return jsonify({"message": f"Hata: {str(e)}"}), 500

@app.route("/load_task", methods=["POST"])
def load_task():
    """
    Görevi JSON dosyasından yüklemek için:
      - formData: { "filename": "gorev.json" }
    Geriye { "message": "...", "data": {...} } döner.
    """
    try:
        filename = request.form.get("filename", "").strip()
        if not filename or not os.path.exists(filename):
            return jsonify({"message": "Görev dosyası bulunamadı.", "data": {}}), 400

        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)

        add_log(f"Görev yüklendi: {filename}")
        return jsonify({"message": f"Görev {filename} dosyasından yüklendi.", "data": data})
    except Exception as e:
        add_log(f"Görev yüklenirken hata: {str(e)}")
        return jsonify({"message": f"Hata: {str(e)}", "data": {}}), 500

# -------------------------
# AYARLARI KAYDET / YÜKLE
# -------------------------
@app.route("/save_config", methods=["POST"])
def save_config():
    """
    Basit ayarları JSON formatında kaydetmek için:
      - payload: {
          "filename": "ayarlar.json",
          "data": {
              "model": "...",
              "temperature": 0.7,
              "max_tokens": 512,
              "top_p": 0.9
          }
        }
    """
    try:
        payload = request.get_json()
        if not payload:
            return jsonify({"message": "Ayar verisi alınamadı."}), 400

        filename = payload.get("filename", "ayarlar.json")
        data = payload.get("data", {})

        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        add_log(f"Ayarlar kaydedildi: {filename}")
        return jsonify({"message": f"Ayarlar {filename} dosyasına kaydedildi."})
    except Exception as e:
        add_log(f"Ayarlar kaydedilirken hata: {str(e)}")
        return jsonify({"message": f"Hata: {str(e)}"}), 500

@app.route("/load_config", methods=["POST"])
def load_config():
    """
    Ayarları JSON dosyasından yüklemek için:
      - formData: { "filename": "ayarlar.json" }
    Geriye { "message": "...", "config": {...} } döner.
    """
    try:
        filename = request.form.get("filename", "").strip()
        if not filename or not os.path.exists(filename):
            return jsonify({"message": "Ayar dosyası bulunamadı.", "config": {}}), 400

        with open(filename, "r", encoding="utf-8") as f:
            config = json.load(f)

        add_log(f"Ayarlar yüklendi: {filename}")
        return jsonify({"message": f"Ayarlar {filename} dosyasından yüklendi.", "config": config})
    except Exception as e:
        add_log(f"Ayarlar yüklenirken hata: {str(e)}")
        return jsonify({"message": f"Hata: {str(e)}", "config": {}}), 500

# -------------------------
# GÖREVİ BAŞLAT / DURDUR
# -------------------------
@app.route("/run_task", methods=["POST"])
def run_task_endpoint():
    global global_agent_thread, global_running
    if global_running:
        return jsonify({"message": "Zaten çalışan bir görev var."}), 400

    task_text = request.form.get("task_text", "").strip()
    if not task_text:
        return jsonify({"message": "Görev metni boş olamaz."}), 400

    global_running = True
    global_agent_thread = threading.Thread(target=run_agent_background, args=(task_text,))
    global_agent_thread.start()

    add_log("Görev çalıştırıldı.")
    return jsonify({"message": "Görev başlatıldı. Tarayıcı açık kalacak."})

@app.route("/stop_task", methods=["POST"])
def stop_task():
    global global_running, global_context, global_browser, global_agent_thread

    if not global_running:
        return jsonify({"message": "Çalışan bir görev yok."}), 400

    global_running = False
    if global_agent_thread:
        global_agent_thread.join(timeout=10)

    async def close_browser():
        if global_context:
            await global_context.close()
        if global_browser:
            await global_browser.close()

    try:
        asyncio.run(close_browser())
    except Exception as e:
        add_log(f"Tarayıcı kapatılırken hata: {str(e)}")

    add_log("Görev durduruldu, tarayıcı kapatıldı.")
    return jsonify({"message": "Görev durduruldu ve tarayıcı kapatıldı."})

# -------------------------
# LOG GEÇMİŞİNİ TEMİZLE
# -------------------------
@app.route("/clear_history", methods=["POST"])
def clear_history():
    global global_task_log
    global_task_log = []
    add_log("Log geçmişi temizlendi.")
    return jsonify({"message": "Geçmiş temizlendi."})

# -------------------------
# Uygulamayı başlat
# -------------------------
if __name__ == "__main__":
    add_log("Uygulama başlatıldı.")
    app.run(debug=True)
